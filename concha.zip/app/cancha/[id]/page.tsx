"use client"

import { Navbar } from "@/components/navbar"
import { FieldDetailView } from "@/components/field-detail-view"
import { notFound } from "next/navigation"
import { useDataStore } from "@/lib/data-store"

export default function CanchaDetailPage({
  params,
}: {
  params: { id: string }
}) {
  const fields = useDataStore((state) => state.fields)
  const allReservations = useDataStore((state) => state.reservations)
  const field = fields.find((f) => f.id === params.id)

  if (!field) {
    notFound()
  }

  const fieldReservations = allReservations.filter((r) => r.fieldId === params.id)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="mx-auto max-w-[1600px] px-4 py-6 md:px-6 md:py-8">
        <FieldDetailView
          fieldName={field.name}
          fieldType={field.type}
          date="Viernes, 10 de Febrero 2025"
          reservations={fieldReservations}
        />
      </main>
    </div>
  )
}
